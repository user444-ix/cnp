go to C:\Windows\System32\drivers\etc
copy and paste the hosts file and choose replace when asked
